RMI wavefield consistency diagnostic — v2 (2026-11-12)
==================================================

Fix for MATLAB error at the recreated AC-map agreement assertion:

Observed large_inclusions output:
  reconstructed PG vs saved PG: P95 2.22341e-05, max 0.00584021 m/s
  reconstructed AC vs saved AC: P95 3.23799e-05, max 46.2427 m/s

The original check stopped on MAX disagreement in a recomputed AC map,
despite near-exact PG agreement and near-exact AC P95 agreement. In the
actual residual comparison, the recomputed AC map is NEVER used. The
saved PG/AC maps and old RMI maps are strictly cross-checked instead.

Changes:
  1. STRICT saved PG/AC provenance checks are unchanged.
  2. STRICT recreated PG agreement check is unchanged (same filter path).
  3. Recreated AC comparison is now diagnostic, restricted to valid
     saved common SWS support with AC between 0 and 10 m/s.
  4. Prints N, P95, P99, max and number/percent of |difference|>=0.2.
     Warns for material disagreement, but isolated AC outliers do not
     prevent evaluating saved AC with the independently verified field.
  5. All original simulations, quality/SWS maps, filters, metrics and
     RMI normalization remain untouched.

Usage:
  Copy diagnose_rmi_wavefield_consistency.m to Analysis/ (replace prior
  diagnostic script only), then run:

    clear diagnose_rmi_wavefield_consistency
    [T, info] = diagnose_rmi_wavefield_consistency('large_inclusions');

  If successful:
    [T, info] = diagnose_rmi_wavefield_consistency();

  The output is in:
    Results/sws_measurement_quality/rmi_wavefield_consistency/

IMPORTANT:
  The saved AC maps are used throughout; the recreated AC is only a
  consistency diagnostic. If a warning reports a material disagreement,
  inspect settings before making strong claims about AC results.
  This diagnostic still uses a 1D x-only Eq.(6) model, even for 12
  angular direction channels; it tests sensitivity to the wavefield,
  not the ultimate validity of a 1D physics model.

MATLAB was not available in the authoring environment, so the fix was
static-checked but not executed on the original datasets.
